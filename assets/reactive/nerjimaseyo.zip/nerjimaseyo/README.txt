==================================================
 월페이퍼엔진 적용 방법 (Wallpaper Engine Guide)
==================================================

[준비물]
- PC (Windows)
- Steam의 Wallpaper Engine (유료 프로그램입니다)


[적용 방법]

1. 받은 zip 파일의 압축을 풉니다.
   (zip 상태로는 열리지 않습니다. 반드시 압축을 풀어주세요.)

2. 압축을 푼 폴더를 지우거나 옮기지 않을 위치에 둡니다.
   예) 바탕화면, 문서 폴더
   폴더 안에 project.json 파일이 바로 보여야 합니다.

3. Wallpaper Engine을 실행합니다.

4. 왼쪽 아래의 [배경화면 열기 (Open Wallpaper)]를 누르고
   [파일에서 열기 (Open from File)]를 선택합니다.
   (메뉴 이름은 언어 설정에 따라 조금 다를 수 있습니다.)

5. 압축을 푼 폴더 안의 project.json 파일을 선택합니다.

6. 목록에 나타난 배경화면을 선택하고 [확인]을 누르면 적용됩니다.

7. 오른쪽 속성 패널에서 설정을 바꿀 수 있습니다.


[다른 방법: Installed(설치됨) 탭에 계속 보이게 하기]

압축을 푼 폴더를 아래 경로 안에 넣고, Wallpaper Engine을 다시 시작합니다.

  <Steam 설치 경로>\steamapps\common\wallpaper_engine\projects\myprojects\

Steam 기본 설치 경로는 보통 C:\Program Files (x86)\Steam 입니다.


[문제가 생겼을 때]

- 화면이 검게 나올 때
  -> zip 안에서 바로 열지 않았는지, 파일이 빠지지 않았는지 확인해 주세요.

- 캐릭터가 움직이지 않거나 반응하지 않을 때
  -> Wallpaper Engine을 완전히 종료했다가 다시 실행해 보세요.

- 마우스 반응이 안 될 때
  -> 바탕화면 빈 곳에서만 반응할 수 있습니다.
     아이콘이나 창 위에서는 동작하지 않을 수 있습니다.

- 폴더를 옮기거나 지웠을 때
  -> 배경화면이 사라지니, 폴더를 원래 위치에 두거나
     4번부터 다시 진행해 주세요.


==================================================
 English
==================================================

[Requirements]
- Windows PC
- Wallpaper Engine (Steam, paid app)

[How to apply]

1. Unzip the downloaded file. It will not work from inside the zip.

2. Put the unzipped folder somewhere permanent (e.g. Documents).
   You should see project.json directly inside the folder.

3. Launch Wallpaper Engine.

4. Click [Open Wallpaper] at the bottom left, then choose [Open from File].

5. Select the project.json file inside the unzipped folder.

6. Select the wallpaper in the list and click [OK] to apply it.

7. You can adjust settings in the properties panel on the right.

[Alternative: keep it in the Installed tab]

Copy the unzipped folder into:

  <Steam install path>\steamapps\common\wallpaper_engine\projects\myprojects\

then restart Wallpaper Engine.
(Default Steam path is usually C:\Program Files (x86)\Steam)

[Troubleshooting]

- Black screen: make sure you unzipped the folder and no files are missing.
- Character does not move/react: fully close and restart Wallpaper Engine.
- Mouse reactions not working: they may only work on empty desktop areas,
  not over icons or windows.
- If you move or delete the folder, the wallpaper will disappear.
  Put it back or start again from step 4.


==================================================
 日本語 (Japanese)
==================================================

[必要なもの]
- Windows PC
- Steam の Wallpaper Engine(有料ソフトです)


[適用方法]

1. ダウンロードした zip ファイルを解凍します。
   (zip のままでは開けません。必ず解凍してください。)

2. 解凍したフォルダを、削除したり移動したりしない場所に置きます。
   例)デスクトップ、ドキュメントフォルダ
   フォルダの中に project.json ファイルが直接表示されている必要があります。

3. Wallpaper Engine を起動します。

4. 左下の [壁紙を開く (Open Wallpaper)] をクリックし、
   [ファイルから開く (Open from File)] を選択します。
   (メニュー名は言語設定によって多少異なる場合があります。)

5. 解凍したフォルダ内の project.json ファイルを選択します。

6. 一覧に表示された壁紙を選択し、[OK] をクリックすると適用されます。

7. 右側のプロパティパネルで設定を変更できます。


[別の方法:「インストール済み」タブに常に表示させる]

解凍したフォルダを下記のパスに入れ、Wallpaper Engine を再起動します。

  <Steam のインストールパス>\steamapps\common\wallpaper_engine\projects\myprojects\

Steam の既定のインストールパスは、通常 C:\Program Files (x86)\Steam です。


[問題が発生した場合]

- 画面が真っ黒になる場合
  -> zip の中から直接開いていないか、ファイルが欠けていないかを確認してください。

- キャラクターが動かない、または反応しない場合
  -> Wallpaper Engine を完全に終了してから、もう一度起動してみてください。

- マウスに反応しない場合
  -> デスクトップの何もない場所でのみ反応することがあります。
     アイコンやウィンドウの上では動作しない場合があります。

- フォルダを移動または削除してしまった場合
  -> 壁紙が消えてしまうため、フォルダを元の場所に戻すか、
     手順4からやり直してください。


==================================================
 이용약관 (한국어)
==================================================
출처: https://rororoha68.github.io/spikiderujibazeyo/#terms

제1조 (목적)
이 약관은 '스핔이 라이브 배경화면'(이하 '본 사이트')에서 무료로 배포하는 배경화면(이하 '배포물')의 이용 조건을 정함을 목적으로 합니다.

제2조 (2차 창작물 및 저작권)
① 배포물은 트릭컬 리바이브을(를) 바탕으로 제작한 비공식 팬 제작물(2차 창작물)이며, 원작 및 원작 권리자와 무관합니다.
② 원작의 캐릭터 등에 대한 권리는 원작 권리자에게 있으며, 배포물에서 제작자가 새로 만든 부분에 대한 권리는 제작자에게 있습니다.
③ 원작 권리자의 가이드라인이 변경되거나 권리자의 요청이 있는 경우, 배포물은 예고 없이 수정되거나 배포가 중단될 수 있습니다.

제3조 (이용 범위)
이용자는 배포물을 본인 기기의 배경화면으로 설정하는 개인적·비상업적 용도에 한하여 무료로 이용할 수 있습니다.

제4조 (금지 행위)
이용자는 다음 행위를 할 수 없습니다.
1. 배포물 파일을 다른 사이트나 서비스에 다시 올리거나 배포하는 행위
2. 배포물을 판매하거나 유료로 제공하는 등 영리 목적으로 이용하는 행위
3. 배포물을 수정·가공하여 배포하는 행위
4. 제작자를 사칭하거나 배포물을 본인이 제작한 것처럼 표시하는 행위
5. 배포물을 인공지능 학습 데이터로 이용하는 행위
6. 배포물을 비방, 혐오, 선정적인 내용 등 원작과 제작자의 이미지를 훼손하는 맥락에 이용하는 행위

제5조 (링크 공유 및 SNS 게시)
① 본 사이트의 링크를 다른 사람에게 공유하는 것은 자유롭게 할 수 있습니다.
② 배경화면을 설정한 화면을 개인 SNS에 게시하는 것은 허용되며, 출처를 표기해 주시기를 권장합니다.

제6조 (서비스 변경 및 중단)
제작자는 사전 고지 없이 배포물을 교체하거나 배포를 중단하거나 본 사이트의 내용을 변경할 수 있습니다.

제7조 (면책)
제작자는 기기 및 운영체제 호환 문제, 설정 실패, 배터리 소모, 데이터 통신 요금, 이용자가 사용하는 외부 앱·프로그램으로 인해 발생한 문제에 대하여 책임을 지지 않습니다.

제8조 (위반 시 조치)
이용자가 이 약관을 위반한 경우 제작자는 해당 게시물의 삭제를 요청할 수 있으며, 필요한 경우 법적 조치를 할 수 있습니다.

제9조 (문의 및 개정)
① 이 약관에 관한 문의는 bpnga2000@gmail.com으로 해 주시기 바랍니다.
② 약관을 개정하는 경우 본 사이트에 공지하며, 개정된 약관은 공지한 때부터 효력이 발생합니다.
③ 이 약관은 2026년 11월 12일부터 시행합니다.

제작: 로하 (https://x.com/rororoha_68)
원작: 트릭컬 리바이브 (https://trickcal.com/)


==================================================
 Terms of Use (English)
==================================================
Source: https://rororoha68.github.io/spikiderujibazeyo/#terms
(English translation of the Korean original. If the two differ, the Korean version applies.)

Article 1 (Purpose)
These Terms set out the conditions for using the wallpapers (the "Content") distributed free of charge at "Spiki Live Wallpaper" (스핔이 라이브 배경화면) (the "Site").

Article 2 (Derivative Works and Copyright)
(1) The Content is an unofficial fan-made work (derivative work) based on Trickcal Revive (트릭컬 리바이브) and is not affiliated with the original work or its rights holders.
(2) Rights to the characters and other elements of the original work belong to the rights holders of the original work, and rights to the parts newly created by the creator belong to the creator.
(3) If the guidelines of the original rights holders change, or if a rights holder so requests, the Content may be modified or its distribution may be stopped without prior notice.

Article 3 (Scope of Use)
Users may use the Content free of charge only for personal, non-commercial purposes, namely setting it as the wallpaper of their own devices.

Article 4 (Prohibited Acts)
Users must not do any of the following:
1. Re-upload or redistribute the Content files on other sites or services
2. Use the Content for profit, such as selling it or offering it for a fee
3. Modify or process the Content and distribute it
4. Impersonate the creator, or present the Content as their own work
5. Use the Content as training data for artificial intelligence
6. Use the Content in a context that damages the image of the original work or the creator, such as defamation, hate, or sexually explicit material

Article 5 (Sharing Links and Posting on Social Media)
(1) Anyone may freely share the link to this Site with others.
(2) Posting a screen on which the wallpaper is set to a personal social media account is allowed, and crediting the source is encouraged.

Article 6 (Changes to or Discontinuation of the Service)
The creator may replace the Content, stop its distribution, or change the contents of this Site without prior notice.

Article 7 (Disclaimer)
The creator is not responsible for problems caused by device or operating system compatibility, failed setup, battery consumption, data charges, or external apps and programs used by the user.

Article 8 (Measures for Violations)
If a user violates these Terms, the creator may request the removal of the relevant post and, where necessary, take legal action.

Article 9 (Inquiries and Amendments)
(1) Please direct inquiries about these Terms to bpnga2000@gmail.com.
(2) If these Terms are amended, the amendment will be announced on this Site and takes effect from the time of announcement.
(3) These Terms take effect on November 12, 2026.

Created by: Roha (https://x.com/rororoha_68)
Original work: Trickcal Revive (https://trickcal.com/)


==================================================
 利用規約 (日本語 / Japanese)
==================================================
出典: https://rororoha68.github.io/spikiderujibazeyo/#terms
(韓国語の原文を日本語に翻訳したものです。内容に相違がある場合は、韓国語版が優先されます。)

第1条(目的)
本規約は、「スピキ ライブ壁紙(스핔이 라이브 배경화면)」(以下「本サイト」)で無料配布する壁紙(以下「配布物」)の利用条件を定めることを目的とします。

第2条(二次創作物および著作権)
① 配布物は『Trickcal Revive(트릭컬 리바이브)』をもとに制作した非公式のファン制作物(二次創作物)であり、原作および原作の権利者とは関係ありません。
② 原作のキャラクター等に関する権利は原作の権利者に帰属し、配布物のうち制作者が新たに制作した部分に関する権利は制作者に帰属します。
③ 原作の権利者のガイドラインが変更された場合、または権利者から要請があった場合、配布物は予告なく修正されたり、配布が中止されたりすることがあります。

第3条(利用範囲)
利用者は、配布物をご自身の端末の壁紙に設定する個人的・非営利的な用途に限り、無料で利用することができます。

第4条(禁止行為)
利用者は、次の行為をしてはなりません。
1. 配布物のファイルを他のサイトやサービスに再アップロードまたは再配布する行為
2. 配布物を販売したり有料で提供したりするなど、営利目的で利用する行為
3. 配布物を修正・加工して配布する行為
4. 制作者になりすます行為、または配布物を自分が制作したものであるかのように表示する行為
5. 配布物を人工知能の学習データとして利用する行為
6. 配布物を、誹謗中傷、ヘイト、性的な内容など、原作や制作者のイメージを損なう文脈で利用する行為

第5条(リンクの共有およびSNSへの投稿)
① 本サイトのリンクを他の人に共有することは自由に行えます。
② 壁紙を設定した画面を個人のSNSに投稿することは許可されており、出典を表記していただくことを推奨します。

第6条(サービスの変更および中止)
制作者は、事前の告知なく、配布物を差し替えたり、配布を中止したり、本サイトの内容を変更したりすることがあります。

第7条(免責)
制作者は、端末やOSの互換性の問題、設定の失敗、バッテリー消費、データ通信料、利用者が使用する外部のアプリ・プログラムに起因して生じた問題について、責任を負いません。

第8条(違反時の措置)
利用者が本規約に違反した場合、制作者は該当する投稿の削除を求めることができ、必要な場合には法的措置をとることができます。

第9条(お問い合わせおよび改定)
① 本規約に関するお問い合わせは、bpnga2000@gmail.com までお願いします。
② 規約を改定する場合は本サイトで告知し、改定後の規約は告知した時点から効力を生じます。
③ 本規約は2026年11月12日から施行します。

制作: ロハ (https://x.com/rororoha_68)
原作: Trickcal Revive(트릭컬 리바이브) (https://trickcal.com/)
